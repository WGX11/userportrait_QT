#ifndef TOOL_H
#define TOOL_H
#include <QString>
#include <QtCore>

QString ConvertString2CSV(QString& s);

#endif // TOOL_H
